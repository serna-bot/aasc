// inlcude functions for like button on change, searching change, and others
function expandType() {
  document.getElementsByClassName("expand-button").classList.toggle("show");
}
